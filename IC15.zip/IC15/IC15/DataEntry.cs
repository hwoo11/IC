﻿//IC15 HwukjunWoo CIS 345 T TH 12:00pm
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Excel = Microsoft.Office.Interop.Excel;

namespace IC15
{
    public partial class DataEntry : Form
    {
        //.NET Object References
        Excel.Application oXL;
        Excel.Workbook oWB;
        Excel.Worksheet oSheet;
        int[] scoreArray;
        int scoreCount;

        public DataEntry()
        {
            InitializeComponent();
            scoreCount = 0;
            scoreArray = new int[10];
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            scoreArray[scoreCount] = Convert.ToInt32(scoreTextBox.Text);
            scoreCount++;
            scoreTextBox.Text = "";
            scoreTextBox.Focus();          
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            oXL = new Excel.Application();
            oXL.Visible = true;
            oWB = oXL.Workbooks.Add();
            oSheet = oWB.Sheets.Add();

            for (int i = 1; i < scoreCount; i++)
            {
                oSheet.Cells[i, 2] = scoreArray[i];
            }
            string fromCell;
            string toCell;

            fromCell = "B1";
            toCell = $"B{scoreCount}";
            oSheet.Cells[(scoreCount+1), 1] = "Average";
            oSheet.Cells[(scoreCount+1), 2] = $"=AVERAGE({fromCell}:{toCell})";
            oSheet.Cells[(scoreCount+2), 1] = "Median";
            oSheet.Cells[(scoreCount+2), 2] = $"=MEDIAN({fromCell}:{toCell})";
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "App Data Files (*.xlsx)|*.xlsx|All Files (*.*)|*.*";
            saveFileDialog.ShowDialog();
            string fileName = saveFileDialog.FileName;
            try
            {
                oWB.SaveAs(fileName);
                
            }
            catch
            {
                MessageBox.Show("There was an Error");
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            try
            {
                oWB.Close();
                oXL.Quit();
            }
            catch
            {
                MessageBox.Show("There was an Error");
            }
            
        }
    }
}
